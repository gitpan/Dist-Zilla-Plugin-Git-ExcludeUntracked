package Fake;

use strict;
use warnings;

1;
